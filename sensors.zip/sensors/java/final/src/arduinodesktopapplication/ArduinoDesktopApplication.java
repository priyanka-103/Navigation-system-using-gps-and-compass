package arduinodesktopapplication;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class ArduinoDesktopApplication {
    public static String hum,temp;
    String serverHostname1;
    DatagramSocket d1;
    InetAddress ip, retiip;
    DatagramPacket send, rec;
    String modifiedSentence;
    public static float cmps;
    public static double glat,glon;

    public void led(String s) {
        try {

            byte[] b = (s.getBytes());
            byte[] receiveData = new byte[1024];
            serverHostname1 = new String("192.168.0.104");

            ip = InetAddress.getByName(serverHostname1);

            d1 = new DatagramSocket();

            send = new DatagramPacket(b, b.length, ip, 81);

            d1.send(send);
            System.out.println("Working");

            rec = new DatagramPacket(receiveData, receiveData.length);
            d1.setSoTimeout(10000);

            d1.receive(rec);
            System.out.println("Working2");
            modifiedSentence = new String(rec.getData());
            cmps = Float.parseFloat(modifiedSentence);
        //compass ends
        //hum
            rec = new DatagramPacket(receiveData, receiveData.length);
            d1.setSoTimeout(10000);

            d1.receive(rec);
            System.out.println("Working2");
            modifiedSentence = new String(rec.getData());
            float a = Float.parseFloat(modifiedSentence);
            if(a>0)
                hum=modifiedSentence;
            System.out.println("hum : " + hum);
        //temp
            rec = new DatagramPacket(receiveData, receiveData.length);
            d1.setSoTimeout(10000);
            d1.receive(rec);
            System.out.println("Working2");
            modifiedSentence = new String(rec.getData());
             a = Float.parseFloat(modifiedSentence);
            if(a>0)
                temp=modifiedSentence;
            System.out.println("temp : " + temp);

    //GPS
            //lat
            rec = new DatagramPacket(receiveData, receiveData.length);
            d1.setSoTimeout(10000);
            d1.receive(rec);
            System.out.println("Working2");
            modifiedSentence = new String(rec.getData());
            glat = Float.parseFloat(modifiedSentence);
            System.out.println("lat : " + glat);
            //lon
            rec = new DatagramPacket(receiveData, receiveData.length);
            d1.setSoTimeout(10000);
            d1.receive(rec);
            System.out.println("Working2");
            modifiedSentence = new String(rec.getData());
            glon = Float.parseFloat(modifiedSentence);
            System.out.println("lon : " + glon);

        //gps end
            InetAddress returnIPAddress = rec.getAddress();

            int port = rec.getPort();

            System.out.println("From server at: "
                    + returnIPAddress
                    + ":" + port);
            System.out.println("Message: " + modifiedSentence);

            d1.close();
        } catch (Exception e) {
            System.out.println("Error:" + e);
        }
    }

}
