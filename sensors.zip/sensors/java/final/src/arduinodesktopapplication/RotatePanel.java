package arduinodesktopapplication;

import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import javax.swing.*;


public class RotatePanel extends JPanel {
   private Image image;
   private float f;
   private double currentAngle;
   private double com_angle;
   public static locations loc;


   public RotatePanel(Image image) {
     this.image = image;
     MediaTracker mt = new MediaTracker(this);
     mt.addImage(image, 0);
     try {
       mt.waitForID(0);
     }
     catch (Exception e) {
       e.printStackTrace();
     }
   }

   private double angleFromCoordinate(double lat2, double lon2, double lat1,
        double lon1) {

          double longitude1 = lon1;
          double longitude2 = lon2;
          double latitude1 = Math.toRadians(lat1);
          double latitude2 = Math.toRadians(lat2);
          double longDiff= Math.toRadians(longitude2-longitude1);
          double y= Math.sin(longDiff)*Math.cos(latitude2);
          double x=Math.cos(latitude1)*Math.sin(latitude2)-Math.sin(latitude1)*Math.cos(latitude2)*Math.cos(longDiff);
          double resultDegree= (Math.toDegrees(Math.atan2(y, x))); 
          //String coordNames[] = {"N","NNE", "NE","ENE","E", "ESE","SE","SSE", "S","SSW", "SW","WSW", "W","WNW", "NW","NNW", "N"};
          //double directionid = Math.round(resultDegree / 22.5); 
          // no of array contain 360/16=22.5
          //if (directionid < 0) {
          //    directionid = directionid + 16;
               //no. of contains in array
         // }
         // String compasLoc=coordNames[(int) directionid];

          return resultDegree ;

}
   
   
   public void rotate() {
   
       System.out.println(ArduinoDesktopApplication.cmps);
       f=ArduinoDesktopApplication.cmps;
       com_angle=Double.parseDouble(new Float(f).toString());
    
       
       double lat1=(loc.s_getLattitudeInSeconds()/3600.0);
       double long1=(loc.s_getLongitudeInSeconds()/3600.0);
       double lat2=(loc.d_getLattitudeInSeconds()/3600.0);
       double long2=(loc.d_getLongitudeInSeconds()/3600.0);
       //System.out.println(lat1+"\n"+long1+"\n"+lat2+"\n"+long2+"\n");

       double route_angle=angleFromCoordinate(lat1,long1,lat2,long2);
       if(route_angle<0)
          // route_angle=360+route_angle;
       
       route_angle= (route_angle+360) % 360;
       route_angle= (route_angle+180) % 360;
       
       System.out.println("\n\nroute "+route_angle+"\n\n");

       currentAngle=com_angle-route_angle;
       currentAngle+=270.0;

       if(currentAngle<0)
       {
           currentAngle=360.0+currentAngle;
       }
       //currentAngle+=60.0;
  
     if (currentAngle >= 360.0) {
       currentAngle = currentAngle%360.0;
     }
        System.err.println("print suru");
        repaint();
        System.out.println("\n\nresult "+currentAngle+"\n\n");
        //System.err.println("print sesh");
    
   }
       
   @Override
   public void paint(Graphics g) {
     super.paintComponent(g);
     Graphics2D g2d = (Graphics2D)g;
     AffineTransform origXform = g2d.getTransform();
     AffineTransform newXform = (AffineTransform)(origXform.clone());
     //center of rotation is center of the panel
     int xRot = this.getWidth()/2;
     int yRot = this.getHeight()/2;
     newXform.rotate(Math.toRadians(currentAngle), xRot, yRot);
     g2d.setTransform(newXform);
     //draw image centered in panel
     int x = (getWidth() - image.getWidth(this))/2;
     int y = (getHeight() - image.getHeight(this))/2;
     g2d.drawImage(image, x, y, this);
     g2d.setTransform(origXform);
   }

   public Dimension getPreferredSize() {
     return new Dimension (image.getWidth(this), image.getHeight(this));
   }


   public static void main(String[] args) {
     JFrame f = new JFrame();                                     
     Container cp = f.getContentPane();
     cp.setLayout(new BorderLayout());
     Image testImage =
         Toolkit.getDefaultToolkit().getImage("I:/study/erc/final Folder/ERC_Full_Interfacing/java_code_Compass/UrcCompass/src/arduinodesktopapplication/images.jpg");
     final RotatePanel rotatePanel = new RotatePanel(testImage);
    
     JButton b = new JButton ("Rotate");
     
     loc= new locations();
     loc.setVisible(true); 
     
     b.addActionListener(new ActionListener() 
     {
       public void actionPerformed(ActionEvent ae) 
       {
          ArduinoDesktopApplication c=new ArduinoDesktopApplication();
          c.led("1");
          
           
           rotatePanel.rotate();
          
        }
     });
     cp.add(rotatePanel, BorderLayout.CENTER);
    // cp.add(b, BorderLayout.SOUTH);
     f.pack();
     f.setSize(600, 600);
     f.setLocationRelativeTo(null);
     f.setVisible(true);
     ArduinoDesktopApplication c=new ArduinoDesktopApplication();
         while(true){ //ArduinoDesktopApplication c=new ArduinoDesktopApplication();
          c.led("1");
          rotatePanel.rotate();
          //i++;
    }
   }
}
